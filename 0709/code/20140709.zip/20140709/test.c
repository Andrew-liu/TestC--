#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, const char *argv[])
{
    int *pi = malloc(1000);

    char *s = malloc(1000);
    return 0;
}
