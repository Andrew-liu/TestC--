#include <stdio.h>
#include <stdlib.h>
#include <string.h>




int main(int argc, const char *argv[])
{
    int A[9];
    int (*arr)[9] = &A; 
    return 0;
}
