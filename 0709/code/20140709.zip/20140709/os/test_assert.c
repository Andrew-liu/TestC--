#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

int main(int argc, const char *argv[])
{
    assert(2 == 3);
    return 0;
}
