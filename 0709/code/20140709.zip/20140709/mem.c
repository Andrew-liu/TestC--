#include <stdio.h>
#include <stdlib.h>
#include <string.h>


void test(void){
    int *ptr = malloc(1000);
}

int main(int argc, const char *argv[])
{
    char *s = malloc(1000);
    return 0;
}
