#include <stdio.h>
int main(int argc, const char *argv[])
{
    int a = add(1, 2);
    printf("%d\n", a);
    return 0;
}
