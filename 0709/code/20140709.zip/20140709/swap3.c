#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef int T;

//交换T类型变量
void swap(T *a, T *b){
    T temp = *a;
    *a = *b;
    *b = temp;
}


int main(int argc, const char *argv[])
{
    
    return 0;
}
