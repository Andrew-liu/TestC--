#!/bin/sh

cd ./
tar czvf shell.tar.gz *.sh

cd ../
mkdir backup
cd -
cp shell.tar.gz ../backup/
